"use client"

import { useState } from "react"
import ModelSelector from "@/components/model-selector"
import ClassificationForm from "@/components/classification-form"
import ForecastingForm from "@/components/forecasting-form"
import ResultsDisplay from "@/components/results-display"
import { BarChart3, TrendingUp } from "lucide-react"

export default function Home() {
  const [selectedModel, setSelectedModel] = useState<"classification" | "forecasting" | null>(null)
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const handleModelSelect = (model: "classification" | "forecasting") => {
    setSelectedModel(model)
    setResults(null)
    setError("")
  }

  const handleSubmit = async (formData: any) => {
    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: selectedModel,
          data: formData,
        }),
      })

      const contentType = response.headers.get("content-type")
      if (!contentType?.includes("application/json")) {
        const text = await response.text()
        console.error("[v0] Non-JSON response:", text)
        setError("Server returned invalid response")
        return
      }

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "Prediction failed")
      } else {
        setResults(data)
      }
    } catch (err) {
      console.error("[v0] Error:", err)
      setError(err instanceof Error ? err.message : "Error communicating with server")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-slate-100">
      <div className="bg-gradient-to-r from-primary via-blue-700 to-primary/90 text-white shadow-lg">
        <div className="container mx-auto px-4 sm:px-6 py-6 sm:py-8">
          <div className="flex items-center gap-2 sm:gap-3 mb-2">
            <BarChart3 className="w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0" />
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">Port Authority Analytics</h1>
          </div>
          <p className="text-blue-100 text-sm sm:text-base lg:text-lg">
            New York & New Jersey • Advanced Traffic Forecasting & Revenue Intelligence
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          <div className="lg:col-span-1">
            <ModelSelector selectedModel={selectedModel} onSelectModel={handleModelSelect} />
          </div>

          <div className="lg:col-span-2 space-y-6 sm:space-y-8">
            {!selectedModel ? (
              <div className="bg-card rounded-xl shadow-lg p-8 sm:p-12 text-center border border-border">
                <TrendingUp className="w-12 h-12 sm:w-16 sm:h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg sm:text-xl font-semibold text-foreground mb-2">Get Started</h3>
                <p className="text-sm sm:text-base text-muted-foreground">
                  Select a model from above to begin your analysis
                </p>
              </div>
            ) : selectedModel === "forecasting" ? (
              <ForecastingForm onSubmit={handleSubmit} loading={loading} error={error} />
            ) : (
              <ClassificationForm onSubmit={handleSubmit} loading={loading} error={error} />
            )}

            {results && <ResultsDisplay model={selectedModel} results={results} />}
          </div>
        </div>
      </div>
    </main>
  )
}
