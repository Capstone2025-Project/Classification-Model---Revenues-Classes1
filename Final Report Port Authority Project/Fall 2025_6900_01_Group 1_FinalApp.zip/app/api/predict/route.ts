import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    console.log("[v0] API received request")

    const body = await request.json()
    console.log("[v0] Request body:", body)

    const { model, data } = body

    if (!model || !data) {
      console.log("[v0] Missing model or data")
      return NextResponse.json({ error: "Missing model or data" }, { status: 400 })
    }

    if (model !== "classification" && model !== "forecasting") {
      return NextResponse.json({ error: "Invalid model type" }, { status: 400 })
    }

    let result: any

    if (model === "classification") {
      result = generateClassificationPrediction(data)
    } else {
      result = generateForecastingPrediction(data)
    }

    console.log("[v0] Prediction result:", result)
    return NextResponse.json(result)
  } catch (error) {
    console.error("[v0] Prediction error:", error)
    const errorMessage = error instanceof Error ? error.message : "Prediction failed"
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}

function generateClassificationPrediction(data: any) {
  try {
    // Extract input features from form data
    const { facility, date, time, dayName, payment, violation, traffic, peakHour } = data

    console.log("[v0] Classification inputs:", {
      facility,
      date,
      time,
      dayName,
      payment,
      violation,
      traffic,
      peakHour,
    })

    // Generate mock prediction based on traffic level
    const trafficLevel = Number.parseFloat(traffic) || 0
    let revenuePrediction: "High" | "Medium" | "Low"
    let confidence: number

    if (trafficLevel > 5000) {
      revenuePrediction = "High"
      confidence = 0.85 + Math.random() * 0.1
    } else if (trafficLevel > 2000) {
      revenuePrediction = "Medium"
      confidence = 0.75 + Math.random() * 0.1
    } else {
      revenuePrediction = "Low"
      confidence = 0.7 + Math.random() * 0.1
    }

    return {
      model: "classification",
      facility,
      date,
      prediction: revenuePrediction,
      confidence: Math.round(confidence * 100) / 100,
      probabilities: {
        High: revenuePrediction === "High" ? confidence : (1 - confidence) / 2,
        Medium: revenuePrediction === "Medium" ? confidence : (1 - confidence) / 2,
        Low: revenuePrediction === "Low" ? confidence : (1 - confidence) / 2,
      },
      input: data,
    }
  } catch (err) {
    console.error("[v0] Classification prediction error:", err)
    throw new Error("Failed to generate classification prediction")
  }
}

function generateForecastingPrediction(data: any) {
  try {
    const {
      facility,
      date,
      dayName,
      isHoliday,
      avgWindSpeed,
      avgPrecipitation,
      avgSnowfall,
      avgSnowDepth,
      avgTempMax,
      avgTempMin,
    } = data

    console.log("[v0] Forecasting inputs:", {
      facility,
      date,
      dayName,
      isHoliday,
      avgWindSpeed,
      avgPrecipitation,
      avgSnowfall,
      avgSnowDepth,
      avgTempMax,
      avgTempMin,
    })

    // These values are approximately daily averages from the Final Dataset
    const facilityBaseTraffic: Record<string, number> = {
      Bayonne: 11000,
      Goethals: 50000,
      "GWB Lower": 56000,
      "GWB PIP": 70000,
      "GWB Upper": 90000,
      Holland: 45000,
      Lincoln: 51000,
      Outerbridge: 43000,
    }

    const baseTraffic = facilityBaseTraffic[facility] || 50000

    // Apply weather factors (more conservative adjustments)
    const tempFactor = (avgTempMax + avgTempMin) / 2 - 60 // Normalized to 60°F baseline
    const tempEffect = tempFactor * 5 // ±5 vehicles per degree

    const precipitationEffect = -avgPrecipitation * 500 // Rain reduces traffic
    const snowEffect = -avgSnowfall * 1000 // Snow significantly reduces traffic
    const windEffect = -Math.abs(avgWindSpeed - 10) * 20 // Extreme winds reduce traffic

    // Holiday factor
    const holidayFactor = isHoliday ? -2000 : 0

    // Day of week factor (weekends typically lighter)
    const dayWeekendFactor = ["Saturday", "Sunday"].includes(dayName) ? -1500 : 0

    const predictedTraffic = Math.max(
      baseTraffic * 0.7, // Floor at 70% of base traffic
      baseTraffic + tempEffect + precipitationEffect + snowEffect + windEffect + holidayFactor + dayWeekendFactor,
    )

    const confidence = 0.75 + Math.random() * 0.15

    return {
      model: "forecasting",
      facility,
      date,
      traffic: Math.round(predictedTraffic),
      confidence: Math.round(confidence * 100) / 100,
      input: data,
    }
  } catch (err) {
    console.error("[v0] Forecasting prediction error:", err)
    throw new Error("Failed to generate forecasting prediction")
  }
}
