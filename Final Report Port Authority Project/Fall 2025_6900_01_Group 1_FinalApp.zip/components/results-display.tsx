"use client"

import { TrendingUp, DollarSign, AlertCircle } from "lucide-react"

interface ResultsDisplayProps {
  model: "classification" | "forecasting"
  results: any
}

export default function ResultsDisplay({ model, results }: ResultsDisplayProps) {
  if (model === "classification") {
    return (
      <div className="bg-card rounded-xl shadow-lg p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 border border-border">
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="p-1.5 sm:p-2 bg-accent/10 rounded-lg flex-shrink-0">
            <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
          </div>
          <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">Revenue Classification Result</h3>
        </div>

        {results.error ? (
          <div className="bg-destructive/10 border border-destructive/30 text-destructive px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg flex items-start gap-2 text-sm">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{results.error}</span>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
              <div className="bg-gradient-to-br from-success/10 to-success/5 p-4 sm:p-6 rounded-xl border-2 border-success/30">
                <p className="text-xs sm:text-sm text-muted-foreground font-medium mb-1">Predicted Revenue Class</p>
                <p className="text-3xl sm:text-4xl font-bold text-success mt-2">{results.prediction}</p>
              </div>

              <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-4 sm:p-6 rounded-xl border-2 border-primary/30">
                <p className="text-xs sm:text-sm text-muted-foreground font-medium mb-1">Confidence Score</p>
                <p className="text-3xl sm:text-4xl font-bold text-primary mt-2">
                  {(results.confidence * 100).toFixed(1)}%
                </p>
              </div>
            </div>

            {results.probabilities && (
              <div className="bg-muted/30 p-4 sm:p-6 rounded-xl border border-border">
                <h4 className="font-semibold text-sm sm:text-base text-foreground mb-3 sm:mb-4">Class Probabilities</h4>
                <div className="space-y-3 sm:space-y-4">
                  {Object.entries(results.probabilities).map(([className, prob]: [string, any]) => (
                    <div key={className}>
                      <div className="flex justify-between mb-2">
                        <span className="text-xs sm:text-sm font-medium text-foreground">{className}</span>
                        <span className="text-xs sm:text-sm font-bold text-foreground">{(prob * 100).toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2.5 sm:h-3 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-primary to-accent h-2.5 sm:h-3 rounded-full transition-all duration-500"
                          style={{ width: `${prob * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    )
  }

  return (
    <div className="bg-card rounded-xl shadow-lg p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 border border-border">
      <div className="flex items-center gap-2 sm:gap-3">
        <div className="p-1.5 sm:p-2 bg-primary/10 rounded-lg flex-shrink-0">
          <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
        </div>
        <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">Traffic Forecast Results</h3>
      </div>

      {results.error ? (
        <div className="bg-destructive/10 border border-destructive/30 text-destructive px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg flex items-start gap-2 text-sm">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <span>{results.error}</span>
        </div>
      ) : (
        <>
          <div className="bg-gradient-to-br from-primary/10 via-blue-500/5 to-primary/5 p-5 sm:p-6 lg:p-8 rounded-xl border-2 border-primary/30">
            <p className="text-xs sm:text-sm text-muted-foreground font-medium mb-1">
              Forecasted Traffic for {results.date}
            </p>
            <p className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mt-2 sm:mt-3">
              {Math.round(results.traffic).toLocaleString()}
            </p>
            <p className="text-sm sm:text-base text-muted-foreground mt-2 sm:mt-3 font-medium">
              vehicles • {results.facility}
            </p>
            <div className="mt-4 sm:mt-6">
              <div className="flex justify-between items-center mb-2">
                <p className="text-xs sm:text-sm text-muted-foreground font-medium">Forecast Confidence</p>
                <p className="text-xs sm:text-sm text-primary font-bold">{(results.confidence * 100).toFixed(0)}%</p>
              </div>
              <div className="w-full bg-secondary rounded-full h-2.5 sm:h-3 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-primary to-chart-1 h-2.5 sm:h-3 rounded-full transition-all duration-500"
                  style={{ width: `${results.confidence * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
