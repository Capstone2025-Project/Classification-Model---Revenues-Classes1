"use client"

import type React from "react"

import { useState, useEffect } from "react"

interface ForecastingFormProps {
  onSubmit: (formData: any) => void
  loading: boolean
  error: string
}

const MONTHLY_WEATHER_AVERAGES: Record<
  number,
  {
    avgWindSpeed: number
    avgPrecipitation: number
    avgSnowfall: number
    avgSnowDepth: number
    avgTempMax: number
    avgTempMin: number
  }
> = {
  0: { avgWindSpeed: 10, avgPrecipitation: 3.5, avgSnowfall: 7, avgSnowDepth: 5, avgTempMax: 39, avgTempMin: 26 }, // January
  1: { avgWindSpeed: 10, avgPrecipitation: 2.8, avgSnowfall: 6, avgSnowDepth: 7, avgTempMax: 42, avgTempMin: 28 }, // February
  2: { avgWindSpeed: 9, avgPrecipitation: 4.0, avgSnowfall: 3, avgSnowDepth: 2, avgTempMax: 51, avgTempMin: 35 }, // March
  3: { avgWindSpeed: 8, avgPrecipitation: 4.1, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 62, avgTempMin: 44 }, // April
  4: { avgWindSpeed: 7, avgPrecipitation: 4.2, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 72, avgTempMin: 54 }, // May
  5: { avgWindSpeed: 6, avgPrecipitation: 4.5, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 81, avgTempMin: 64 }, // June
  6: { avgWindSpeed: 6, avgPrecipitation: 4.6, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 85, avgTempMin: 69 }, // July
  7: { avgWindSpeed: 6, avgPrecipitation: 4.3, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 84, avgTempMin: 68 }, // August
  8: { avgWindSpeed: 6, avgPrecipitation: 4.1, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 77, avgTempMin: 61 }, // September
  9: { avgWindSpeed: 7, avgPrecipitation: 3.7, avgSnowfall: 0, avgSnowDepth: 0, avgTempMax: 66, avgTempMin: 50 }, // October
  10: { avgWindSpeed: 8, avgPrecipitation: 3.5, avgSnowfall: 1, avgSnowDepth: 0, avgTempMax: 55, avgTempMin: 41 }, // November
  11: { avgWindSpeed: 9, avgPrecipitation: 3.8, avgSnowfall: 4, avgSnowDepth: 2, avgTempMax: 43, avgTempMin: 31 }, // December
}

export default function ForecastingForm({ onSubmit, loading, error }: ForecastingFormProps) {
  const [formData, setFormData] = useState({
    facility: "GWB Lower",
    date: new Date().toISOString().split("T")[0],
    dayName: "", // Will be auto-calculated
    isHoliday: false,
    avgWindSpeed: 5,
    avgPrecipitation: 0,
    avgSnowfall: 0,
    avgSnowDepth: 0,
    avgTempMax: 72,
    avgTempMin: 60,
  })

  const [showSuggestions, setShowSuggestions] = useState(false)

  const facilities = ["Bayonne", "Goethals", "GWB Lower", "GWB PIP", "GWB Upper", "Holland", "Lincoln", "Outerbridge"]

  useEffect(() => {
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const dateObj = new Date(formData.date + "T00:00:00")
    const dayName = dayNames[dateObj.getDay()]
    const month = dateObj.getMonth()

    const monthlyAvg = MONTHLY_WEATHER_AVERAGES[month]

    setFormData((prev) => ({
      ...prev,
      dayName,
      avgWindSpeed: monthlyAvg.avgWindSpeed,
      avgPrecipitation: monthlyAvg.avgPrecipitation,
      avgSnowfall: monthlyAvg.avgSnowfall,
      avgSnowDepth: monthlyAvg.avgSnowDepth,
      avgTempMax: monthlyAvg.avgTempMax,
      avgTempMin: monthlyAvg.avgTempMin,
    }))
  }, [formData.date])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target

    if (type === "checkbox") {
      setFormData((prev) => ({
        ...prev,
        [name]: (e.target as HTMLInputElement).checked,
      }))
    } else {
      setFormData((prev) => ({
        ...prev,
        [name]: isNaN(Number(value)) ? value : Number(value),
      }))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-card rounded-xl shadow-lg p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 border border-border"
    >
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-foreground">Traffic Forecasting</h2>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Predict daily vehicle volume using time series analysis
        </p>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive/30 text-destructive px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="bg-primary/5 p-4 sm:p-5 rounded-xl border border-primary/20">
        <h3 className="font-semibold text-sm sm:text-base text-foreground mb-3 sm:mb-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0"></span>
          Required Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">Facility *</label>
            <select
              name="facility"
              value={formData.facility}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            >
              {facilities.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
              Date to Forecast *
            </label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            />
          </div>
        </div>

        {formData.dayName && (
          <div className="mt-3 px-3 py-2 bg-card rounded-lg text-xs sm:text-sm text-muted-foreground border border-border">
            <span className="font-medium text-foreground">Day:</span> {formData.dayName}
          </div>
        )}
      </div>

      <div className="bg-muted/30 p-4 sm:p-5 rounded-xl border border-border">
        <h3 className="font-semibold text-sm sm:text-base text-foreground mb-3 sm:mb-4">Additional Variables</h3>

        <div className="mb-3 sm:mb-4">
          <label className="flex items-center gap-2 text-xs sm:text-sm font-medium text-foreground cursor-pointer">
            <input
              type="checkbox"
              name="isHoliday"
              checked={formData.isHoliday}
              onChange={handleChange}
              className="w-4 h-4 border border-border rounded accent-primary flex-shrink-0"
            />
            This date is a holiday
          </label>
        </div>

        <div className="bg-accent/10 p-3 sm:p-4 rounded-lg border border-accent/20">
          <div className="mb-3">
            <h4 className="font-medium text-sm sm:text-base text-foreground">Weather Conditions</h4>
            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
              Values below show historical averages for this month. Update with recent weather forecasts for improved
              accuracy.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 mt-3 sm:mt-4">
            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Wind Speed (mph)
              </label>
              <input
                type="number"
                name="avgWindSpeed"
                value={formData.avgWindSpeed}
                onChange={handleChange}
                step="0.1"
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Precipitation (in)
              </label>
              <input
                type="number"
                name="avgPrecipitation"
                value={formData.avgPrecipitation}
                onChange={handleChange}
                step="0.01"
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Snowfall (in)
              </label>
              <input
                type="number"
                name="avgSnowfall"
                value={formData.avgSnowfall}
                onChange={handleChange}
                step="0.01"
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Snow Depth (in)
              </label>
              <input
                type="number"
                name="avgSnowDepth"
                value={formData.avgSnowDepth}
                onChange={handleChange}
                step="0.01"
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Max Temperature (°F)
              </label>
              <input
                type="number"
                name="avgTempMax"
                value={formData.avgTempMax}
                onChange={handleChange}
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>

            <div>
              <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
                Min Temperature (°F)
              </label>
              <input
                type="number"
                name="avgTempMin"
                value={formData.avgTempMin}
                onChange={handleChange}
                className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-primary hover:bg-primary/90 disabled:bg-muted disabled:text-muted-foreground text-primary-foreground py-3 sm:py-3.5 rounded-lg font-semibold transition-colors shadow-md hover:shadow-lg text-sm sm:text-base"
      >
        {loading ? "Computing Forecast..." : "Compute Forecast"}
      </button>
    </form>
  )
}
