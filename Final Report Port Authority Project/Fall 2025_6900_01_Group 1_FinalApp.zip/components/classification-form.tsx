"use client"

import type React from "react"

import { useState, useEffect } from "react"

interface ClassificationFormProps {
  onSubmit: (formData: any) => void
  loading: boolean
  error: string
}

export default function ClassificationForm({ onSubmit, loading, error }: ClassificationFormProps) {
  const [formData, setFormData] = useState({
    facility: "GWB",
    date: new Date().toISOString().split("T")[0],
    time: "12:00",
    dayName: "",
    traffic: 5200,
    peakHour: "No",
  })

  const facilities = ["GWB", "Goethals", "Lincoln", "Holland", "Outerbridge", "Bayonne"]

  useEffect(() => {
    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    const dateObj = new Date(formData.date + "T00:00:00")
    const dayName = dayNames[dateObj.getDay()]

    setFormData((prev) => ({
      ...prev,
      dayName,
    }))
  }, [formData.date])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: isNaN(Number(value)) ? value : Number(value),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-card rounded-xl shadow-lg p-4 sm:p-6 lg:p-8 space-y-4 sm:space-y-6 border border-border"
    >
      <div>
        <h2 className="text-xl sm:text-2xl font-bold text-foreground">Revenue Classification</h2>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Predict revenue category based on hourly traffic patterns
        </p>
      </div>

      {error && (
        <div className="bg-destructive/10 border border-destructive/30 text-destructive px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg text-sm">
          {error}
        </div>
      )}

      <div className="bg-primary/5 p-4 sm:p-5 rounded-xl border border-primary/20">
        <h3 className="font-semibold text-sm sm:text-base text-foreground mb-3 sm:mb-4 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0"></span>
          Required Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">Facility *</label>
            <select
              name="facility"
              value={formData.facility}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            >
              {facilities.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">Date *</label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            />
          </div>
        </div>

        {formData.dayName && (
          <div className="mt-3 px-3 py-2 bg-card rounded-lg text-xs sm:text-sm text-muted-foreground border border-border">
            <span className="font-medium text-foreground">Day:</span> {formData.dayName}
          </div>
        )}
      </div>

      <div className="bg-success/10 p-4 sm:p-5 rounded-xl border-2 border-success/30">
        <h3 className="font-semibold text-sm sm:text-base text-foreground mb-1.5 sm:mb-2 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-success flex-shrink-0"></span>
          Traffic Volume (Primary Variable)
        </h3>
        <p className="text-xs text-muted-foreground mb-3 sm:mb-4 leading-relaxed">
          Main factor influencing revenue. Note: This model predicts based on <strong>hourly</strong> traffic patterns.
        </p>

        <div>
          <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">
            Hourly Traffic Count *
          </label>
          <input
            type="number"
            name="traffic"
            value={formData.traffic}
            onChange={handleChange}
            className="w-full px-3 sm:px-4 py-2.5 sm:py-3 text-base sm:text-lg bg-input border-2 border-success/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-success focus:border-success text-foreground font-semibold"
            placeholder="Enter hourly traffic volume"
          />
          <p className="text-xs text-muted-foreground mt-2">
            Expected range: 100-5000+ vehicles per hour depending on facility and time
          </p>
        </div>
      </div>

      <div className="bg-muted/30 p-4 sm:p-5 rounded-xl border border-border">
        <h3 className="font-semibold text-sm sm:text-base text-foreground mb-3 sm:mb-4">Additional Variables</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">Time</label>
            <input
              type="time"
              name="time"
              value={formData.time}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            />
          </div>

          <div>
            <label className="block text-xs sm:text-sm font-medium text-foreground mb-1.5 sm:mb-2">Peak Hour</label>
            <select
              name="peakHour"
              value={formData.peakHour}
              onChange={handleChange}
              className="w-full px-3 sm:px-4 py-2 sm:py-2.5 text-sm sm:text-base bg-input border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
            >
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={loading}
        className="w-full bg-accent hover:bg-accent/90 disabled:bg-muted disabled:text-muted-foreground text-accent-foreground py-3 sm:py-3.5 rounded-lg font-semibold transition-colors shadow-md hover:shadow-lg text-sm sm:text-base"
      >
        {loading ? "Computing..." : "Compute Prediction"}
      </button>
    </form>
  )
}
