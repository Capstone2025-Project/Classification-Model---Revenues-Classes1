"use client"

import { TrendingUp, DollarSign } from "lucide-react"

interface ModelSelectorProps {
  selectedModel: "classification" | "forecasting" | null
  onSelectModel: (model: "classification" | "forecasting") => void
}

export default function ModelSelector({ selectedModel, onSelectModel }: ModelSelectorProps) {
  return (
    <div className="space-y-4">
      <div className="mb-4 sm:mb-6">
        <h2 className="text-xl sm:text-2xl font-bold text-foreground mb-1">Analysis Tools</h2>
        <p className="text-xs sm:text-sm text-muted-foreground">Choose your prediction model</p>
      </div>

      <button
        onClick={() => onSelectModel("forecasting")}
        className={`w-full p-4 sm:p-6 rounded-xl border-2 transition-all text-left group ${
          selectedModel === "forecasting"
            ? "border-primary bg-primary/5 shadow-lg"
            : "border-border bg-card hover:border-primary/50 hover:shadow-md"
        }`}
      >
        <div className="flex items-start gap-3 sm:gap-4">
          <div
            className={`p-2 sm:p-3 rounded-lg flex-shrink-0 ${
              selectedModel === "forecasting"
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground group-hover:bg-primary/10"
            }`}
          >
            <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base sm:text-lg font-semibold text-foreground mb-1">Traffic Forecaster</h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              Predict daily vehicle volumes using SARIMA time series analysis
            </p>
          </div>
        </div>
      </button>

      <button
        onClick={() => onSelectModel("classification")}
        className={`w-full p-4 sm:p-6 rounded-xl border-2 transition-all text-left group ${
          selectedModel === "classification"
            ? "border-success bg-success/5 shadow-lg"
            : "border-border bg-card hover:border-success/50 hover:shadow-md"
        }`}
      >
        <div className="flex items-start gap-3 sm:gap-4">
          <div
            className={`p-2 sm:p-3 rounded-lg flex-shrink-0 ${
              selectedModel === "classification"
                ? "bg-success text-success-foreground"
                : "bg-secondary text-secondary-foreground group-hover:bg-success/10"
            }`}
          >
            <DollarSign className="w-5 h-5 sm:w-6 sm:h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base sm:text-lg font-semibold text-foreground mb-1">Revenue Classifier</h3>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              Classify revenue levels (High/Medium/Low) based on traffic patterns
            </p>
          </div>
        </div>
      </button>
    </div>
  )
}
