"""
Wrapper script to run predictions from Node.js
Usage: python run_prediction.py <model_type> <json_data>
"""
import sys
import json
from prediction_service import get_prediction_service

if __name__ == "__main__":
    try:
        model_type = sys.argv[1]
        data_json = sys.argv[2]
        data = json.loads(data_json)
        
        service = get_prediction_service()
        
        if model_type == "classification":
            result = service.predict_revenue(data)
        elif model_type == "forecasting":
            result = service.forecast_traffic(data)
        else:
            raise ValueError(f"Unknown model type: {model_type}")
        
        # Output result as JSON to stdout
        print(json.dumps(result))
        sys.exit(0)
        
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
