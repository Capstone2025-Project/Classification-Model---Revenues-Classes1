"""
Classification Model Training Script
Trains XGBoost model to predict Revenue Classes (High/Medium/Low)
Based on traffic volume and operational features only
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
import pickle
import os

# Create models directory
os.makedirs('public/models', exist_ok=True)

# Load dataset
df = pd.read_csv('scripts/data/sample_dataset.csv')
print(f"Dataset loaded: {df.shape}")

# Focus on traffic as the main predictor of revenue class
feature_columns = ['Facility', 'Traffic (Vehicles)', 'Day Name', 'Peak Hour']

# Try to include time-related features if they exist
if 'Hour' in df.columns:
    feature_columns.append('Hour')
if 'Time' in df.columns:
    feature_columns.append('Time')

# Prepare data
target = "Revenues Class"
df = df.dropna(subset=[target])

# Only keep available feature columns
available_features = [col for col in feature_columns if col in df.columns]
X = df[available_features]
y = df[target]

print(f"Using features: {available_features}")
print(f"Feature columns: {X.columns.tolist()}")

# Detect column types
num_cols = X.select_dtypes(include=['int64','float64']).columns.tolist()
cat_cols = X.select_dtypes(include=['object']).columns.tolist()

print(f"Numeric columns: {num_cols}")
print(f"Categorical columns: {cat_cols}")

# Encode target
le = LabelEncoder()
y_enc = le.fit_transform(y)

# Create preprocessing pipeline
num_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="mean"))
])
cat_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
])

preprocess = ColumnTransformer([
    ("num", num_pipe, num_cols),
    ("cat", cat_pipe, cat_cols)
])

xgb = XGBClassifier(
    booster="gbtree",
    colsample_bytree=0.9,
    eta=0.3,
    gamma=0,
    grow_policy="depthwise",
    max_depth=6,
    n_estimators=100,
    objective="multi:softprob",
    reg_alpha=1.0,
    reg_lambda=1.0,
    subsample=0.8,
    tree_method="hist",
    random_state=42,
    num_class=len(le.classes_)
)

model = Pipeline([
    ("pre", preprocess),
    ("clf", xgb)
])

# Train model
X_train, X_test, y_train, y_test = train_test_split(X, y_enc, stratify=y_enc, test_size=0.25, random_state=42)
print("Training classification model...")
model.fit(X_train, y_train)

# Save model and label encoder
with open('public/models/classification_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('public/models/label_encoder.pkl', 'wb') as f:
    pickle.dump(le, f)

print("Classification model saved!")
print(f"Classes: {le.classes_}")
print(f"Training accuracy: {model.score(X_train, y_train):.4f}")
print(f"Testing accuracy: {model.score(X_test, y_test):.4f}")

print("\n--- Sample Predictions ---")
sample_facilities = X['Facility'].unique()[:2]
for facility in sample_facilities:
    for traffic in [500, 1000, 2000, 3000]:
        sample = pd.DataFrame({
            'Facility': [facility],
            'Traffic (Vehicles)': [traffic],
            'Day Name': ['Wednesday'],
            'Peak Hour': ['No']
        })
        # Add other features if they exist
        if 'Hour' in available_features:
            sample['Hour'] = [12]
        if 'Time' in available_features:
            sample['Time'] = ['12:00']
        
        pred_class = le.inverse_transform(model.predict(sample))[0]
        probs = model.predict_proba(sample)[0]
        print(f"{facility} - Traffic: {traffic} -> {pred_class} (confidence: {max(probs):.2f})")
