"""
Forecasting Model Training Script
Trains SARIMA models for each facility
"""
import pandas as pd
import numpy as np
import pickle
import os
from statsmodels.tsa.statespace.sarimax import SARIMAX
import warnings

warnings.filterwarnings("ignore")

# Create models directory
os.makedirs('public/models', exist_ok=True)

# Load dataset
df = pd.read_csv('scripts/data/final_dataset.csv')
print(f"Dataset loaded: {df.shape}")

# Convert date
df['Date'] = pd.to_datetime(df['Date'], format='%m/%d/%Y')

# Train model for each facility
facility_models = {}
unique_facilities = df['Facility'].unique()

print(f"Training models for {len(unique_facilities)} facilities...")

for facility in unique_facilities:
    df_facility = df[df['Facility'] == facility].copy()
    df_facility = df_facility.sort_values('Date')
    df_facility = df_facility.set_index('Date')
    
    # Resample to daily and fill missing data
    ts = df_facility['Total_Traffic'].resample('D').mean().fillna(method='ffill')
    
    if len(ts) < 14:  # Need minimum data
        print(f"⚠️ Skipping {facility} (insufficient data)")
        continue
    
    try:
        # Fit SARIMA model
        model = SARIMAX(
            ts, 
            order=(2, 1, 2), 
            seasonal_order=(1, 0, 1, 7),
            enforce_stationarity=False, 
            enforce_invertibility=False
        )
        model_fit = model.fit(disp=False)
        facility_models[facility] = model_fit
        print(f"✓ {facility}")
    except Exception as e:
        print(f"✗ {facility}: {str(e)}")

# Save all models
with open('public/models/forecasting_models.pkl', 'wb') as f:
    pickle.dump(facility_models, f)

print(f"\nForecasting models saved! ({len(facility_models)} facilities)")
