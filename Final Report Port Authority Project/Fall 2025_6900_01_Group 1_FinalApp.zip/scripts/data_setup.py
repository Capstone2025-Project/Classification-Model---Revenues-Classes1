"""
Copy datasets to accessible location
"""
import shutil
import os

os.makedirs('scripts/data', exist_ok=True)

# Copy datasets (users will add these)
print("Datasets should be placed in scripts/data/:")
print("- sample_dataset.csv (for classification)")
print("- final_dataset.csv (for forecasting)")
