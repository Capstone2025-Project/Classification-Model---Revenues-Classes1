import pandas as pd
import numpy as np
import warnings
import pickle
import io
import sys
from pathlib import Path

warnings.filterwarnings("ignore")

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

print("[v0] Starting model training pipeline...")

# ===== CLASSIFICATION MODEL =====
print("\n[v0] Training Classification Model...")

from sklearn.preprocessing import OneHotEncoder, LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier

# Load classification dataset
df_class = pd.read_csv("scripts/sample_dataset.csv")
print(f"[v0] Classification dataset loaded: {df_class.shape}")

target = "Revenues Class"
df_class = df_class.dropna(subset=[target])
X_class = df_class.drop(columns=[target])
y_class = df_class[target]

# Detect column types
num_cols = X_class.select_dtypes(include=['int64','float64']).columns.tolist()
cat_cols = X_class.select_dtypes(include=['object']).columns.tolist()

# Handle date columns
date_cols = []
for c in cat_cols:
    try:
        pd.to_datetime(X_class[c])
        date_cols.append(c)
    except:
        pass

for c in date_cols:
    s = pd.to_datetime(X_class[c], errors='coerce')
    X_class[c + '_year'] = s.dt.year
    X_class[c + '_month'] = s.dt.month
    X_class[c + '_day'] = s.dt.day
    X_class[c + '_weekday'] = s.dt.weekday

X_class = X_class.drop(columns=date_cols)
cat_cols = [c for c in X_class.select_dtypes(include=['object']).columns]

# Encode target
le_class = LabelEncoder()
y_class_enc = le_class.fit_transform(y_class)

# Preprocessing pipeline
num_pipe = Pipeline([("imputer", SimpleImputer(strategy="mean"))])
cat_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
])

preprocess = ColumnTransformer([
    ("num", num_pipe, num_cols),
    ("cat", cat_pipe, cat_cols)
])

# XGBoost model
xgb_clf = XGBClassifier(
    booster="gbtree",
    colsample_bytree=1,
    eta=0.4,
    gamma=0,
    grow_policy="lossguide",
    max_bin=255,
    max_depth=10,
    max_leaves=0,
    n_estimators=50,
    objective="multi:softmax",
    reg_alpha=2.3958333333333335,
    reg_lambda=0.20833333333333334,
    subsample=0.6,
    tree_method="hist",
    random_state=42,
    num_class=len(le_class.classes_)
)

classification_model = Pipeline([
    ("preprocess", preprocess),
    ("clf", xgb_clf)
])

classification_model.fit(X_class, y_class_enc)
print("[v0] Classification model trained successfully")

# Save classification model
with open("scripts/classification_model.pkl", "wb") as f:
    pickle.dump({
        "model": classification_model,
        "label_encoder": le_class,
        "num_cols": num_cols,
        "cat_cols": cat_cols
    }, f)
print("[v0] Classification model saved")

# ===== FORECASTING MODEL =====
print("\n[v0] Training Forecasting Model...")

from statsmodels.tsa.statespace.sarimax import SARIMAX

# Load forecasting dataset
df_forecast = pd.read_csv("scripts/final_dataset.csv")
print(f"[v0] Forecasting dataset loaded: {df_forecast.shape}")

# Train SARIMA model for each facility
df_forecast['Date'] = pd.to_datetime(df_forecast['Date'], format='%m/%d/%Y', errors='coerce')
facilities = df_forecast['Facility'].unique()
print(f"[v0] Found {len(facilities)} facilities")

sarima_models = {}
for facility in facilities:
    try:
        df_fac = df_forecast[df_forecast['Facility'] == facility].copy()
        df_fac = df_fac.set_index('Date')
        ts_data = df_fac['Total_Traffic'].resample('D').mean().fillna(method='ffill')
        
        if len(ts_data) < 30:
            print(f"[v0] Skipping {facility} - insufficient data")
            continue
        
        model = SARIMAX(
            ts_data,
            order=(2, 1, 2),
            seasonal_order=(1, 0, 1, 7),
            enforce_stationarity=False,
            enforce_invertibility=False
        )
        model_fit = model.fit(disp=False)
        sarima_models[facility] = model_fit
        print(f"[v0] Trained SARIMA model for {facility}")
    except Exception as e:
        print(f"[v0] Error training {facility}: {str(e)}")

# Save forecasting models
with open("scripts/forecasting_models.pkl", "wb") as f:
    pickle.dump(sarima_models, f)
print("[v0] Forecasting models saved")

print("\n[v0] Model training pipeline completed successfully!")
